x=manu2018
unique(x$X9)
table(is.na(x))
which(x$X5!=x$X6)

########
x = x[-which(x$X9=="B"),]
y = x[,c(5,10,11,13,14)]
table(is.na(y))

A=filter(y, y$X10<=10802)
B=filter(y, 11111<=y$X10 & y$X10<=11209)
C=filter(y, y$X10==12000)
D=filter(y, 13101<=y$X10 & y$X10<=13991)
E=filter(y, 14111<=y$X10 & y$X10<=14499)
F=filter(y, 15110<=y$X10 & y$X10<=15220)
G=filter(y, 16101<=y$X10 & y$X10<=16300)
H=filter(y, 17110<=y$X10 & y$X10<=17909)
I=filter(y, 18111<=y$X10 & y$X10<=18200)
J=filter(y, 19101<=y$X10 & y$X10<=19229)
K=filter(y, 20111<=y$X10 & y$X10<=20502)
L=filter(y, 21101<=y$X10 & y$X10<=21300)
M=filter(y, 22111<=y$X10 & y$X10<=22299)
N=filter(y, 23111<=y$X10 & y$X10<=23999)
O=filter(y, 24111<=y$X10 & y$X10<=24329)
P=filter(y, 25111<=y$X10 & y$X10<=25999)
Q=filter(y, 26111<=y$X10 & y$X10<=26600)
R=filter(y, 27111<=y$X10 & y$X10<=27400)
S=filter(y, 28111<=y$X10 & y$X10<=28909)
T=filter(y, 29111<=y$X10 & y$X10<=29299)
U=filter(y, 30110<=y$X10 & y$X10<=30400)
V=filter(y, 31111<=y$X10 & y$X10<=31999)
W=filter(y, 32011<=y$X10 & y$X10<=32099)
X=filter(y, 33110<=y$X10 & y$X10<=33999)
Y=filter(y, 34011<=y$X10 & y$X10<=34020)

y$code=data.frame(rep(NA,69513))
y[which(y$X10<=10802),6]="A"
y[which(11111<=y$X10 & y$X10<=11209),6]="B"
y[which(y$X10==12000),6]="C"
y[which(13101<=y$X10 & y$X10<=13991),6]="D"
y[which(14111<=y$X10 & y$X10<=14499),6]="E"
y[which(15110<=y$X10 & y$X10<=15220),6]="F"
y[which(16101<=y$X10 & y$X10<=16300),6]="G"
y[which(17110<=y$X10 & y$X10<=17909),6]="H"
y[which(18111<=y$X10 & y$X10<=18200),6]="I"
y[which(19101<=y$X10 & y$X10<=19229),6]="J"
y[which(20111<=y$X10 & y$X10<=20502),6]="K"
y[which(21101<=y$X10 & y$X10<=21300),6]="L"
y[which(22111<=y$X10 & y$X10<=22299),6]="M"
y[which(23111<=y$X10 & y$X10<=23999),6]="N"
y[which(24111<=y$X10 & y$X10<=24329),6]="O"
y[which(25111<=y$X10 & y$X10<=25999),6]="P"
y[which(26111<=y$X10 & y$X10<=26600),6]="Q"
y[which(27111<=y$X10 & y$X10<=27400),6]="R"
y[which(28111<=y$X10 & y$X10<=28909),6]="S"
y[which(29111<=y$X10 & y$X10<=29299),6]="T"
y[which(30110<=y$X10 & y$X10<=30400),6]="U"
y[which(31111<=y$X10 & y$X10<=31999),6]="V"
y[which(32011<=y$X10 & y$X10<=32099),6]="W"
y[which(33110<=y$X10 & y$X10<=33999),6]="X"
y[which(34011<=y$X10 & y$X10<=34020),6]="Y"

y= y[,-2]
colnames(y)=c("people","income","produce","value","code")
sum_people=summarise(group_by(y,code), sum_people=sum(people))
sum_income=summarise(group_by(y,code), sum_income=sum(income))
sum_produce=summarise(group_by(y,code), sum_produce=sum(produce))
sum_value=summarise(group_by(y,code), sum_value=sum(value))

data=data.frame(sum_people,sum_income,sum_produce,sum_value)
rownames(data)=data$code
data=data[,-c(1,3,5,7)]
data

data=as.matrix(data)
data=scale(data)
str(data)

##heatmap
install.packages("gplots")
library("gplots")
heatmap.2(data, col=bluered(100),trace="none",density.info="none")

install.packages("pheatmap")
library("pheatmap")
pheatmap(data, cutree_rows=25)


